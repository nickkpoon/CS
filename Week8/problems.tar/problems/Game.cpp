#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctype.h>
#include "TwentyQuestionsTree.h"

using namespace std;

int main(int argc, char *argv[])
{
  TwentyQuestionsTree *tree;
  FILE *fp;

  // TODO:
  // if there was a command-line argument,
  // assume it is the filename and pass in a file to initialize
  // tree

  // fp = .....

  // otherwise, use default constructor
  tree = new TwentyQuestionsTree();

  int play;
  do{
    char buf[256];
    // start the game
    tree->reset();
    const char *question = tree->currentQuestion();
    const char *lastquestion;
    int answer = 0;
    while(question != NULL)
      {
        // ask the question
        printf("%s (yes=1, no=0): ", question);
        // read the response
        fgets(buf, 256, stdin);
        answer = atoi(buf);
        if (answer == 0)
          printf("No\n");
        else
          printf("Yes\n");
        tree->recordAnswer(answer);
        lastquestion = question;
        question = tree->currentQuestion();
      }
    // check to see if computer was correct
    if (answer == 1)
      printf("Yippee!  I got it right!\n");
    else
      {
        printf("What should I have guessed?\n");
        printf("(i.e. Is it a platypus?)?  ");
        char *o;
        char realanswer[300], otherquestion[256];
        fgets(realanswer, 256, stdin);
        // strip last \n
        strtok(realanswer, "\n");
        printf("Real answer: %s\n", realanswer);
        printf("What question would have distinguished this from %s\n",
               lastquestion);
        fgets(otherquestion, 256, stdin);
        // strip last \n, leading spaces
        strtok(otherquestion, "\n");
        printf("Other question: %s\n", otherquestion);
        do{
          printf("Would the answer to that question have been yes or no (yes=1,\
no=0)? ");
          o = fgets(buf, 256, stdin);
          answer = atoi(o);
        } while(!isdigit(*o));
        if (answer == 0)
          tree->modifyAndInsert(strdup(otherquestion), strdup(realanswer),
                                lastquestion);
        else
          tree->modifyAndInsert(strdup(otherquestion), lastquestion,
                                strdup(realanswer));
      }

    printf("Would you like to play again (yes=1,no=0)?");
    fgets(buf, 256, stdin);
    play = atoi(buf);
  } while(play == 1);
  // TODO
  // if a filename was given, reopen the file for writing and
  // write out the current state of the tree
}

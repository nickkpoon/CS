#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "TwentyQuestionsTree.h"

TwentyQuestionsTree::TwentyQuestionsTree(FILE *fp)
{
  // TODO Implement the constructor that builds the initial tree from the file
}

TwentyQuestionsTree::TwentyQuestionsTree()
{
  root = new BinaryNode("Is it a platypus?");
}

/* insert
 * This inserts two questions into the tree - the children of the parent.
 * This is used when building the tree from scratch.
 * The assumption is that the parent is already in the tree, and we are
 * merely adding the left and right children.
 */
bool TwentyQuestionsTree::insert(BinaryNode *r, const char *parent,
                                 const char *left, const char *right)
{
  // TODO
  return false;
}

/* modifyAndInsert
 *
 * This modifies the tree as a result of the game being incorrect.  Either
 * the left child or right child is already in the tree.  This method replaces
 * that existing one with the new parent and creates new left and right
 * children.
 */
bool TwentyQuestionsTree::modifyAndInsert(BinaryNode *n, const char *parent,
                                          const char *left, const char *right)
{
  // TODO
  return false;
}

void TwentyQuestionsTree::modifyAndInsert(const char *parent, const char *left,
                                          const char *right)
{
  // TODO
}

/* reset
 *
 * This resets the iterator to the beginning of the game
 */
void TwentyQuestionsTree::reset()
{
  // TODO (remove the following when you implement this function)
  printf("This code currently does not work.\n");
  printf("You need to implement the reset method\n");
  printf("You need to implement the recordAnswer method\n");
  printf("in TwentyQuestionsTree.cpp to make the iterator.\n");
}

/* currentQuestions
 *
 * This has been provided for you.  This looks at the current position of
 * the iterator and returns the question stored in that BinaryNode.
 */
const char *TwentyQuestionsTree::currentQuestion()
{
  if (iterator == NULL)
    return NULL;
  else
    return iterator->question;
}

/* recordAnswer
 *
 * This advances the iterator.  If the answer was yes (1), go right.  If
 * no (0), go left.
 */
void TwentyQuestionsTree::recordAnswer(int answer)
{
  // TODO (remove the following when you implement this function)
  printf("This code currently does not work.\n");
  printf("You need to implement the recordAnswer method\n");
  printf("in TwentyQuestionsTree.cpp to make the iterator\n");
}

/* storeTree
 *
 * This writes the tree out to the file in the same format as the
 * sample input file was.
 */
void TwentyQuestionsTree::storeTree(BinaryNode *n,FILE *fp)
{
  // TODO
}
void TwentyQuestionsTree::storeTree(FILE *fp)
{
  // TODO
}
